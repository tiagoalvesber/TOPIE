* Jape grammar files are under Examples folder. They are numbered against the Example number from the Tutorial. 
As mentioned in the tutorial, vim(http://www.vim.org/) is one of the better editors that you can use to edit/view JAPE files.

* The examples/datastore folder contains datastore (with the text files) and is already annotated and ready to be used with the example JAPE grammar files. 